<?php require_once 'vue/header.php'; ?>

<div class="container mt-4">
    <?php if (!isset($reservation) || !is_array($reservation)): ?>
        <div class="alert alert-danger">
            <h2>Erreur</h2>
            <p>Les informations de réservation sont manquantes.</p>
            <a href="index.php" class="btn btn-primary">Retour à l'accueil</a>
        </div>
    <?php else: ?>
        <h1>Effectuer le paiement</h1>

        <div class="card">
            <div class="card-body">
                <h2>Récapitulatif de la réservation</h2>
                <div class="reservation-details mb-4">
                    <p><strong>Montant à payer :</strong> <?= htmlspecialchars($reservation['prix_total'] ?? '0') ?> €</p>
                    <p><strong>Véhicule :</strong> <?= htmlspecialchars($reservation['marque'] ?? '') ?> <?= htmlspecialchars($reservation['modele'] ?? '') ?></p>
                    <p><strong>Période :</strong> 
                        Du <?= htmlspecialchars(date('d/m/Y', strtotime($reservation['date_debut'] ?? 'now'))) ?> 
                        au <?= htmlspecialchars(date('d/m/Y', strtotime($reservation['date_fin'] ?? 'now'))) ?>
                    </p>
                </div>

                <form action="index.php?controller=paiement&action=effectuer&id=<?= htmlspecialchars($reservation['id_reservation'] ?? '') ?>" 
                      method="POST" 
                      class="mt-4">
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Mode de paiement</label>
                        <div class="form-check">
                            <input type="radio" id="carte" name="mode_paiement" value="carte" class="form-check-input" required>
                            <label class="form-check-label" for="carte">Carte bancaire</label>
                        </div>
                        <div class="form-check">
                            <input type="radio" id="virement" name="mode_paiement" value="virement" class="form-check-input">
                            <label class="form-check-label" for="virement">Virement bancaire</label>
                        </div>
                        <div class="form-check">
                            <input type="radio" id="paypal" name="mode_paiement" value="paypal" class="form-check-input">
                            <label class="form-check-label" for="paypal">PayPal</label>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <button type="submit" class="btn btn-primary">Confirmer le paiement</button>
                        <a href="index.php?controller=reservation&action=liste" class="btn btn-secondary">Annuler</a>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'vue/footer.php'; ?>