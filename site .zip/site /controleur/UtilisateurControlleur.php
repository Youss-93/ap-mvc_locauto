<?php
class UtilisateurControlleur {
    private $utilisateurModel;

    public function __construct() {
        require_once 'modele/Utilisateur.php';
        $this->utilisateurModel = new Utilisateur();
    }

    public function login() {
        if (isset($_SESSION['utilisateur'])) {
            header('Location: index.php');
            exit();
        }
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $password = $_POST['password'] ?? '';
            
            // Debug temporaire
            var_dump($_POST); // Pour voir les données envoyées
            
            $utilisateur = $this->utilisateurModel->verifierLogin($email, $password);
            if ($utilisateur) {
                // Stocke l'email au lieu de l'ID comme identifiant principal
                $_SESSION['utilisateur'] = $utilisateur['email'];
                $_SESSION['nom'] = $utilisateur['nom_utilisateur'];
                $_SESSION['prenom'] = $utilisateur['prenom_utilisateur'];
                $_SESSION['id_utilisateur'] = $utilisateur['id_utilisateur'];
                $_SESSION['role'] = $utilisateur['role_utilisateur'];
                $_SESSION['message'] = 'Connexion réussie';
                $_SESSION['message_type'] = 'success';
                header('Location: index.php');
                exit();
            } else {
                $erreur = "Email ou mot de passe incorrect";
            }
        }
        require_once 'vue/login.php';
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // Sanitize inputs
                $nom = htmlspecialchars($_POST['nom'] ?? '', ENT_QUOTES, 'UTF-8');
                $prenom = htmlspecialchars($_POST['prenom'] ?? '', ENT_QUOTES, 'UTF-8');
                $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
                $password = $_POST['password'] ?? '';
                $tel = htmlspecialchars($_POST['tel'] ?? '', ENT_QUOTES, 'UTF-8');
    
                // Validate inputs
                if (empty($nom) || empty($prenom) || empty($email) || empty($password) || empty($tel)) {
                    throw new Exception('Tous les champs sont obligatoires');
                }
    
                if (strlen($password) < 6) {
                    throw new Exception('Le mot de passe doit contenir au moins 6 caractères');
                }
    
                if (!preg_match("/^[0-9]{10}$/", $tel)) {
                    throw new Exception('Le numéro de téléphone doit contenir 10 chiffres');
                }
    
                // Check if email already exists
                if ($this->utilisateurModel->emailExists($email)) {
                    throw new Exception('Cet email est déjà utilisé');
                }
    
                // Create user with role 'client'
                if ($this->utilisateurModel->creer($nom, $prenom, $email, $password, $tel, 'client')) {
                    $_SESSION['message'] = 'Compte créé avec succès';
                    $_SESSION['message_type'] = 'success';
                    header('Location: index.php?controller=utilisateur&action=login');
                    exit();
                } else {
                    throw new Exception('Erreur lors de la création du compte');
                }
            } catch (Exception $e) {
                $_SESSION['message'] = $e->getMessage();
                $_SESSION['message_type'] = 'danger';
                // Keep form data for re-population
                $_SESSION['form_data'] = [
                    'nom' => $nom ?? '',
                    'prenom' => $prenom ?? '',
                    'email' => $email ?? '',
                    'tel' => $tel ?? ''
                ];
            }
        }
    
        require_once 'vue/register.php';
    }

public function emailExists($email) {
    $sql = "SELECT COUNT(*) FROM utilisateur WHERE email = :email";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':email' => $email]);
    return $stmt->fetchColumn() > 0;
}

    public function logout() {
        session_destroy();
        header('Location: index.php');
        exit();
    }

    public function profil() {
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }
    
        // Récupérer les informations de l'utilisateur
        $utilisateur = $this->utilisateurModel->getUtilisateur($_SESSION['id_utilisateur']);
    
        // Récupérer les réservations de l'utilisateur
        require_once 'modele/Reservation.php';
        $reservationModel = new Reservation();
        $reservations = $reservationModel->getReservationsUtilisateur($_SESSION['id_utilisateur']);
    
        require_once 'vue/profil.php';
    }

    public function modifier() {
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_STRING);
            $prenom = filter_input(INPUT_POST, 'prenom', FILTER_SANITIZE_STRING);
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $tel = filter_input(INPUT_POST, 'tel', FILTER_SANITIZE_STRING);
    
            if ($this->utilisateurModel->modifier($_SESSION['id_utilisateur'], $nom, $prenom, $email, $tel)) {
                $_SESSION['message'] = 'Profil mis à jour avec succès';
                $_SESSION['message_type'] = 'success';
                header('Location: index.php?controller=utilisateur&action=profil');
                exit();
            } else {
                $_SESSION['message'] = 'Erreur lors de la mise à jour du profil';
                $_SESSION['message_type'] = 'error';
            }
           
        }
    
        // Récupérer les informations de l'utilisateur
        $utilisateur = $this->utilisateurModel->getUtilisateur($_SESSION['id_utilisateur']);
    
        require_once 'vue/profil.modifier.php';
    }

    public function supprimer() {
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_utilisateur = $_SESSION['id_utilisateur'];
            if ($this->utilisateurModel->supprimer($id_utilisateur)) {
                session_destroy();
                $_SESSION['message'] = 'Compte supprimé avec succès';
                $_SESSION['message_type'] = 'success';
                header('Location: index.php');
                exit();
            } else {
                $_SESSION['message'] = 'Erreur lors de la suppression du compte';
                $_SESSION['message_type'] = 'error';
            }
        }
    
        require_once 'vue/profil.supprimer.php';
    }

    
}
