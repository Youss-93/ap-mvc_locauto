<?php 
class Voiture {
    private $db;

    public function __construct(){
        $this->db = Database::getConnection();
    }

    public function ajouter($data) {
        try {
            $sql = "INSERT INTO voiture (marque, modele, année, prix_jour, caution, disponibilité, image_loc) 
                    VALUES (:marque, :modele, :annee, :prix_jour, :caution, :disponibilite, :image_loc)";
            
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([
                ':marque' => $data['marque'],
                ':modele' => $data['modele'],
                ':annee' => $data['annee'],
                ':prix_jour' => $data['prix_jour'],
                ':caution' => $data['caution'],
                ':disponibilite' => $data['disponibilite'],
                ':image_loc' => $data['image_loc']
            ]);
    
            return $result;
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function getListe () {
        $sql = "SELECT * FROM voiture ORDER BY id_voiture ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    public function getListeDispo () {
        $sql = "SELECT * FROM voiture WHERE disponibilité = TRUE";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    public function getListeNonDispo () {
        $sql = "SELECT * FROM voiture WHERE disponibilité = FALSE";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    public function getVoiture($id) {
        $sql = "SELECT * FROM Voiture WHERE id_voiture = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function getVoituresDisponibles() {
        $sql = "SELECT * FROM Voiture WHERE disponibilité = TRUE ORDER BY id_voiture ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }
    
    public function modifier($id, $data) {
        try {
            $sql = "UPDATE voiture 
                    SET marque = :marque,
                        modele = :modele,
                        année = :annee,
                        prix_jour = :prix_jour,
                        caution = :caution,
                        disponibilité = :disponibilite
                    WHERE id_voiture = :id";
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':id' => $id,
                ':marque' => $data['marque'],
                ':modele' => $data['modele'],
                ':annee' => $data['annee'],
                ':prix_jour' => $data['prix_jour'],
                ':caution' => $data['caution'],
                ':disponibilite' => $data['disponibilite'] ?? true
            ]);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    
    public function modifierDisponibilite($id, $disponibilite) {
        $sql = "UPDATE Voiture SET disponibilité = :disponibilité WHERE id_voiture = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':disponibilite' => $disponibilite
        ]);
    }
    
    public function supprimer($id) {
        $sql = "DELETE FROM Voiture WHERE id_voiture = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

}