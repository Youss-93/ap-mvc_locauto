<?php
class ReservationControlleur {
    private $reservationModel;
    private $voitureModel;

    public function __construct() {
        require_once 'modele/Reservation.php';
        require_once 'modele/Voiture.php';
        $this->reservationModel = new Reservation();
        $this->voitureModel = new Voiture();
    }

    public function creer() {
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Récupération et validation des données
            $id_voiture = filter_input(INPUT_POST, 'id_voiture', FILTER_VALIDATE_INT);
            $date_debut = filter_input(INPUT_POST, 'date_debut');
            $date_fin = filter_input(INPUT_POST, 'date_fin');

            // Vérifications
            if (!$id_voiture || !$date_debut || !$date_fin) {
                $_SESSION['message'] = 'Tous les champs sont obligatoires';
                $_SESSION['message_type'] = 'danger';
                require_once 'vue/resa.formulaire.php';
                return;
            }

            // Récupérer les informations de la voiture
            $voiture = $this->voitureModel->getVoiture($id_voiture);
            if (!$voiture) {
                $_SESSION['message'] = 'Voiture non trouvée';
                $_SESSION['message_type'] = 'danger';
                header('Location: index.php?controller=voiture&action=liste');
                exit();
            }

            // Calculer le prix total
            $nb_jours = (strtotime($date_fin) - strtotime($date_debut)) / (60 * 60 * 24);
            if ($nb_jours <= 0) {
                $_SESSION['message'] = 'Les dates sont invalides';
                $_SESSION['message_type'] = 'danger';
                require_once 'vue/resa.formulaire.php';
                return;
            }
            $prix_total = $nb_jours * $voiture['prix_jour'];

            // Créer la réservation
            $id_reservation = $this->reservationModel->creer(
                $_SESSION['id_utilisateur'],
                $id_voiture,
                $date_debut,
                $date_fin,
                $prix_total
            );

            if ($id_reservation) {
                // Récupérer la réservation complète
                $reservation = $this->reservationModel->getReservation($id_reservation);
                if ($reservation) {
                    $_SESSION['message'] = 'Réservation créée avec succès';
                    $_SESSION['message_type'] = 'success';
                    require_once 'vue/resa.cree.php';
                    return;
                }
            }

            $_SESSION['message'] = 'Erreur lors de la création de la réservation';
            $_SESSION['message_type'] = 'danger';
            require_once 'vue/resa.formulaire.php';
            return;
        }

        // Afficher le formulaire initial
        $id_voiture = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        $voiture = $this->voitureModel->getVoiture($id_voiture);
        require_once 'vue/resa.formulaire.php';
    }

    public function confirmer() {
        // Vérification des droits admin
        if (!isset($_SESSION['utilisateur']) || $_SESSION['role'] !== 'admin') {
            $_SESSION['message'] = 'Action non autorisée';
            $_SESSION['message_type'] = 'danger';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        // Récupération et validation de l'ID
        $id_reservation = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id_reservation) {
            $_SESSION['message'] = 'ID de réservation invalide';
            $_SESSION['message_type'] = 'danger';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        // Confirmation de la réservation
        if ($this->reservationModel->confirmerReservation($id_reservation)) {
            $_SESSION['message'] = 'Réservation confirmée avec succès';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Erreur lors de la confirmation de la réservation';
            $_SESSION['message_type'] = 'danger';
        }
    
        header('Location: index.php?controller=reservation&action=liste');
        exit();
    } 
    
    public function annuler() {
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }
    
        $id_reservation = $_GET['id'] ?? null;
        if (!$id_reservation) {
            $_SESSION['message'] = 'ID de réservation manquant';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        if ($this->reservationModel->annulerReservation($id_reservation)) {
            $_SESSION['message'] = 'Réservation annulée avec succès';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Erreur lors de l\'annulation de la réservation';
            $_SESSION['message_type'] = 'error';
        }
    
        header('Location: index.php?controller=reservation&action=liste');
        exit();
    }
    
    public function supprimer() {
        if (!isset($_SESSION['utilisateur']) || $_SESSION['role'] !== 'admin') {
            $_SESSION['message'] = 'Action non autorisée';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php');
            exit();
        }
    
        $id_reservation = $_GET['id'] ?? null;
        if (!$id_reservation) {
            $_SESSION['message'] = 'ID de réservation manquant';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        if ($this->reservationModel->supprimer($id_reservation)) {
            $_SESSION['message'] = 'Réservation supprimée avec succès';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Erreur lors de la suppression de la réservation';
            $_SESSION['message_type'] = 'error';
        }
    
        header('Location: index.php?controller=reservation&action=liste');
        exit();
    }

    public function liste() {
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }
    
        // Différent affichage selon le rôle
        if ($_SESSION['role'] === 'admin') {
            // Pour les admins : réservations des voitures dont ils sont propriétaires
            $reservations = $this->reservationModel->getReservationsAdmin($_SESSION['id_utilisateur']);
            require_once 'vue/resa.admin.php';
        } 
       
    }

    public function detail() {
        // Vérification de l'authentification
        if (!isset($_SESSION['utilisateur'])) {
            header('Location: index.php?controller=utilisateur&action=login');
            exit();
        }
    
        // Récupération et validation de l'ID
        $id_reservation = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id_reservation) {
            $_SESSION['message'] = 'ID de réservation invalide';
            $_SESSION['message_type'] = 'danger';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        // Récupération des détails de la réservation
        $reservation = $this->reservationModel->getDetailReservation($id_reservation);
        
        if (!$reservation) {
            $_SESSION['message'] = 'Réservation non trouvée';
            $_SESSION['message_type'] = 'danger';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        // Vérification des permissions
        if ($_SESSION['role'] !== 'admin' && $reservation['client_resa'] !== $_SESSION['id_utilisateur']) {
            $_SESSION['message'] = 'Accès non autorisé';
            $_SESSION['message_type'] = 'danger';
            header('Location: index.php?controller=reservation&action=liste');
            exit();
        }
    
        // Affichage de la vue
        require_once 'vue/resa.detail.php';
    }

}
