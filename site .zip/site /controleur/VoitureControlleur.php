<?php
class VoitureControlleur {
    private $voitureModel;

    public function __construct() {
        require_once 'modele/Voiture.php';
        $this->voitureModel = new Voiture();
    }

    public function liste() {
        $voitures = $this->voitureModel->getListe();
        require_once 'vue/voiture.liste.php';
    }

    public function detail() {
        // Vérifier si l'id existe
        $id = $_GET['id'] ?? null;
        if (!$id) {
            $_SESSION['message'] = 'Identifiant de voiture manquant';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }

        // Récupérer la voiture
        $voiture = $this->voitureModel->getVoiture($id);
        
        // Vérifier si la voiture existe
        if (!$voiture) {
            $_SESSION['message'] = 'Voiture non trouvée';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }

        // Afficher la vue
        require_once 'vue/voiture.detail.php';
    }

    public function supprimer() {
        $this->verifierAdmin();

        $id = $_GET['id'] ?? null;
        if ($id) {
            $this->voitureModel->supprimer($id);
            $_SESSION['message'] = 'Voiture supprimée avec succès';
            $_SESSION['message_type'] = 'success';
        } else {
            $_SESSION['message'] = 'Identifiant de voiture manquant';
            $_SESSION['message_type'] = 'error';
        }
        
        header('Location: index.php?controller=voiture&action=liste');
        exit();
    }
    // Vérifie si l'utilisateur est un administrateur

    private function verifierAdmin() {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            $_SESSION['message'] = 'Accès non autorisé';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php');
            exit();
        }
    }

    public function modifier() {
        $this->verifierAdmin();
    
        $id = $_GET['id'] ?? null;
        if (!$id) {
            $_SESSION['message'] = 'Identifiant de voiture manquant';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // Sanitize and validate input
                $marque = htmlspecialchars($_POST['marque'] ?? '', ENT_QUOTES, 'UTF-8');
                $modele = htmlspecialchars($_POST['modele'] ?? '', ENT_QUOTES, 'UTF-8');
                $annee = filter_input(INPUT_POST, 'annee', FILTER_VALIDATE_INT);
                $prix_jour = filter_input(INPUT_POST, 'prix_jour', FILTER_VALIDATE_FLOAT);
                $caution = filter_input(INPUT_POST, 'caution', FILTER_VALIDATE_FLOAT);
                
                if (empty($marque) || empty($modele) || !$annee || !$prix_jour || !$caution) {
                    throw new Exception('Tous les champs sont obligatoires');
                }
    
                $success = $this->voitureModel->modifier($id, [
                    'marque' => $marque,
                    'modele' => $modele,
                    'annee' => $annee,
                    'prix_jour' => $prix_jour,
                    'caution' => $caution,
                    'disponibilite' => true
                ]);
    
                if ($success) {
                    $_SESSION['message'] = 'Voiture modifiée avec succès';
                    $_SESSION['message_type'] = 'success';
                    header('Location: index.php?controller=voiture&action=liste');
                    exit();
                } else {
                    throw new Exception('Erreur lors de la modification de la voiture');
                }
            } catch (Exception $e) {
                $_SESSION['message'] = $e->getMessage();
                $_SESSION['message_type'] = 'danger';
            }
        }
    
        $voiture = $this->voitureModel->getVoiture($id);
        if (!$voiture) {
            $_SESSION['message'] = 'Voiture non trouvée';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }
    
        require_once 'vue/voiture.modifier.php';
    }


    public function ajouter() {
        $this->verifierAdmin();
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // Sanitize and validate input
                $marque = htmlspecialchars($_POST['marque'] ?? '', ENT_QUOTES, 'UTF-8');
                $modele = htmlspecialchars($_POST['modele'] ?? '', ENT_QUOTES, 'UTF-8');
                $annee = filter_input(INPUT_POST, 'annee', FILTER_VALIDATE_INT);
                $prix_jour = filter_input(INPUT_POST, 'prix_jour', FILTER_VALIDATE_FLOAT);
                $caution = filter_input(INPUT_POST, 'caution', FILTER_VALIDATE_FLOAT);
    
                // Validate required fields
                if (empty($marque) || empty($modele) || !$annee || !$prix_jour || !$caution) {
                    throw new Exception('Tous les champs sont obligatoires');
                }
    
                // Handle image upload
                $image_loc = '';
                if (isset($_FILES['image_loc']) && $_FILES['image_loc']['error'] === 0) {
                    $image_loc = $this->uploadImage($_FILES['image_loc']);
                    if (!$image_loc) {
                        throw new Exception('Erreur lors du téléchargement de l\'image');
                    }
                }
    
                // Create the vehicle with correct parameter names
                $success = $this->voitureModel->ajouter([
                    'marque' => $marque,
                    'modele' => $modele,
                    'annee' => $annee,          // Changed from 'année'
                    'prix_jour' => $prix_jour,
                    'caution' => $caution,
                    'disponibilite' => true,     // Changed from 'disponibilité'
                    'image_loc' => $image_loc
                ]);
    
                if (!$success) {
                    throw new Exception('Erreur lors de l\'ajout dans la base de données');
                }
    
                $_SESSION['message'] = 'Voiture ajoutée avec succès';
                $_SESSION['message_type'] = 'success';
                header('Location: index.php?controller=voiture&action=liste');
                exit();
    
            } catch (Exception $e) {
                $_SESSION['message'] = $e->getMessage();
                $_SESSION['message_type'] = 'danger';
                $voiture = [
                    'marque' => $marque ?? '',
                    'modele' => $modele ?? '',
                    'annee' => $annee ?? '',     // Changed from 'année'
                    'prix_jour' => $prix_jour ?? '',
                    'caution' => $caution ?? ''
                ];
                require_once 'vue/voiture.ajouter.php';
                return;
            }
        }
    
        require_once 'vue/voiture.ajouter.php';
    }
    
    
    public function rechercher() {
        $marque = $_GET['marque'] ?? '';
        $modele = $_GET['modele'] ?? '';
        $annee = $_GET['année'] ?? '';
        $prix_jour = $_GET['prix_jour'] ?? '';

        $voitures = $this->voitureModel->rechercher($marque, $modele, $annee, $prix_jour);
        require_once 'vue/voiture.liste.php';
    }
    public function reserver() {
        $this->verifierUtilisateur();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_voiture = $_POST['id_voiture'] ?? null;
            $date_debut = $_POST['date_debut'] ?? null;
            $date_fin = $_POST['date_fin'] ?? null;
            $prix_total = $_POST['prix_total'] ?? null;
            $id_client = $_SESSION['id_utilisateur'] ?? null;
            $statut = 'en attente'; 
            $id_reservation = $this->reservationModel->creer($id_client, $id_voiture, $date_debut, $date_fin, $prix_total, $statut);
            if ($id_reservation) {
                $_SESSION['message'] = 'Réservation créée avec succès';
                $_SESSION['message_type'] = 'success';
            } else {
                $_SESSION['message'] = 'Erreur lors de la création de la réservation';
                $_SESSION['message_type'] = 'danger';
            }
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }
        $id = $_GET['id'] ?? null;
        if (!$id) {
            $_SESSION['message'] = 'Identifiant de voiture manquant';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }
        $voiture = $this->voitureModel->getVoiture($id);
        if (!$voiture) {
            $_SESSION['message'] = 'Voiture non trouvée';
            $_SESSION['message_type'] = 'error';
            header('Location: index.php?controller=voiture&action=liste');
            exit();
        }
        require_once 'vue/voiture.reserver.php';
    }
  

    private function uploadImage($file) {
        try {
            $target_dir = "assets/photos/";
            if (!file_exists($target_dir)) {
                if (!mkdir($target_dir, 0777, true)) {
                    throw new Exception('Impossible de créer le dossier de destination');
                }
            }
    
            // Validate file type
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowed_types)) {
                throw new Exception('Type de fichier non autorisé');
            }
    
            // Generate unique filename
            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $target_file = $target_dir . uniqid('vehicle_', true) . '.' . $extension;
    
            if (!move_uploaded_file($file['tmp_name'], $target_file)) {
                throw new Exception('Erreur lors du déplacement du fichier');
            }
    
            return $target_file;
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    } 

}