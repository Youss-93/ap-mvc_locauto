<?php require_once 'vue/header.php'; ?>

<div class="container">
    <h1>Nos Voitures Disponibles</h1>

    <?php if(isset($message)): ?>
        <div class="alert alert-<?= $message_type ?? 'info' ?>">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div class="admin-actions">
            <a href="index.php?controller=voiture&action=ajouter" class="btn btn-primary">
                Ajouter une voiture
            </a>
        </div>
    <?php endif; ?>

    <div class="voitures-grid">
        <?php foreach($voitures as $voiture): ?>
            <div class="voiture-card">
                <?php if($voiture['image_loc']): ?>
                    <img src="<?= htmlspecialchars($voiture['image_loc']) ?>" 
                         alt="<?= htmlspecialchars($voiture['marque'] . ' ' . $voiture['modele']) ?>"
                         class="voiture-image">
                <?php endif; ?>

                <div class="voiture-info">
                    <h3><?= htmlspecialchars($voiture['marque'] . ' ' . $voiture['modele']) ?></h3>
                    <p class="annee">Année : <?= htmlspecialchars($voiture['année']) ?></p>
                    <p class="prix">Prix/jour : <?= htmlspecialchars($voiture['prix_jour']) ?> €</p>
                    <p class="caution">Caution : <?= htmlspecialchars($voiture['caution']) ?> €</p>
                    
                    <div class="voiture-actions">
                        <?php if($voiture['disponibilité']): ?>
                            <a href="index.php?controller=reservation&action=creer&id=<?= $voiture['id_voiture'] ?>" 
                               class="btn btn-success">Réserver</a>
                        <?php else: ?>
                            <span class="badge badge-warning">Non disponible</span>
                        <?php endif; ?>

                        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <a href="index.php?controller=voiture&action=modifier&id=<?= $voiture['id_voiture'] ?>" 
                               class="btn btn-secondary">Modifier</a>
                            <a href="index.php?controller=voiture&action=supprimer&id=<?= $voiture['id_voiture'] ?>" 
                               class="btn btn-danger"
                               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette voiture ?')">
                                Supprimer
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'vue/footer.php'; ?>