<?php 
class Utilisateur{
    private $db;

    public function __construct(){
        $this->db = Database::getConnection();

    }

    public function creer($nom, $prenom, $email, $password, $tel, $role = 'client') {
        try {
            // Prepare the SQL statement - Remove id_utilisateur from the INSERT
            $sql = "INSERT INTO utilisateur (
                nom_utilisateur, 
                prenom_utilisateur, 
                email, 
                mdp_utilisateur, 
                num_tel, 
                role_utilisateur
            ) VALUES (
                :nom, 
                :prenom, 
                :email, 
                :password, 
                :tel, 
                :role
            )";
            
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $this->db->prepare($sql);
            $success = $stmt->execute([
                ':nom' => $nom,
                ':prenom' => $prenom,
                ':email' => $email,
                ':password' => $hashed_password,
                ':tel' => $tel,
                ':role' => $role
            ]);
    
            if (!$success) {
                error_log('Erreur SQL: ' . implode(', ', $stmt->errorInfo()));
                return false;
            }
    
            return true;
        } catch (PDOException $e) {
            error_log('Erreur PDO: ' . $e->getMessage());
            return false;
        }
    }
    
    public function emailExists($email) {
        $sql = "SELECT COUNT(*) FROM utilisateur WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email' => $email]);
        return $stmt->fetchColumn() > 0;
    }
    
    public function verifierLogin($email, $password) {
        // Vérifie d'abord si l'email existe
        $sql = "SELECT * FROM utilisateur WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email' => $email]);
        $utilisateur = $stmt->fetch();
    
        // Debug temporaire
        var_dump($utilisateur); // Pour voir les données récupérées
        var_dump($password); // Pour voir le mot de passe envoyé
    
        if ($utilisateur && $utilisateur['mdp_utilisateur'] === $password) {
            return $utilisateur;
        }
        return false;
    }

    // afin de recuperer un utilisateur par son id
    public function getUtilisateur($id){
        $sql = "SELECT * FROM utilisateur WHERE id_utilisateur = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    // afin de recuperer un utilisateur par son email
    public function getUtilisateurByEmail($email){
        $sql = "SELECT * FROM utilisateur WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email' => $email]);
        return $stmt->fetch();
    }

    // Update - Modifier les informations d'un utilisateur
    public function modifier($id, $nom, $prenom, $email, $tel) {
        $sql = "UPDATE Utilisateur 
                SET nom_utilisateur = :nom, 
                    prenom_utilisateur = :prenom, 
                    email = :email, 
                    num_tel = :tel 
                WHERE id_utilisateur = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':nom' => $nom,
            ':prenom' => $prenom,
            ':email' => $email,
            ':tel' => $tel
        ]);
    }



    // Update - Modifier le mot de passe
    public function modifierMotDePasse($id, $nouveau_mdp) {
        $sql = "UPDATE Utilisateur 
                SET mdp_utilisateur = :mdp 
                WHERE id_utilisateur = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':mdp' => password_hash($nouveau_mdp, PASSWORD_DEFAULT)
        ]);
    }

    // Delete - Supprimer un utilisateur
    public function supprimer($id) {
        $sql = "DELETE FROM Utilisateur WHERE id_utilisateur = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    // Vérifier si l'email existe déjà
    public function emailExiste($email) {
        $sql = "SELECT COUNT(*) as count FROM Utilisateur WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email' => $email]);
        return $stmt->fetch()['count'] > 0;
    }
}

