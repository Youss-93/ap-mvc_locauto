<?php
class Reservation {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

   
    public function creer($id_client, $id_voiture, $date_debut, $date_fin) {
        $sql = "INSERT INTO Reservation (client_resa, voiture_resa, date_debut, date_fin, statut_reservation) 
                VALUES (:client, :voiture, :debut, :fin, 'en attente')";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':client' => $id_client,
            ':voiture' => $id_voiture,
            ':debut' => $date_debut,
            ':fin' => $date_fin
        ]);
    }

    // Read
    public function getReservation($id) {
        $sql = "SELECT r.*, v.marque, v.modele, v.prix_jour,
                DATEDIFF(r.date_fin, r.date_debut) * v.prix_jour as prix_total
                FROM reservation r
                JOIN voiture v ON r.voiture_resa = v.id_voiture
                WHERE r.id_reservation = :id";
                
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function getReservationsUtilisateur($id_utilisateur) {
        $sql = "SELECT r.*, v.marque, v.modele, v.prix_jour,
                DATEDIFF(r.date_fin, r.date_debut) * v.prix_jour as prix_total
                FROM reservation r
                JOIN voiture v ON r.voiture_resa = v.id_voiture
                WHERE r.client_resa = :id_utilisateur
                ORDER BY r.date_debut DESC";
                
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_utilisateur' => $id_utilisateur]);
        return $stmt->fetchAll();
    }

    public function getReservationsAdmin($id_admin) {
        $sql = "SELECT r.*, v.marque, v.modele, v.prix_jour, 
                u.nom_utilisateur, u.prenom_utilisateur,
                DATEDIFF(r.date_fin, r.date_debut) * v.prix_jour as prix_total
                FROM reservation r
                JOIN voiture v ON r.voiture_resa = v.id_voiture
                JOIN utilisateur u ON r.client_resa = u.id_utilisateur
                WHERE v.id_admin = :id_admin
                ORDER BY r.date_debut DESC";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([':id_admin' => $id_admin]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return [];
        }
    }

    public function getDetailReservation($id_reservation) {
        try {
            $sql = "SELECT r.*, 
                    v.marque, v.modele, v.prix_jour, v.caution, v.image_loc,
                    u.nom_utilisateur, u.prenom_utilisateur, u.email, u.num_tel,
                    DATEDIFF(r.date_fin, r.date_debut) * v.prix_jour as prix_total
                    FROM reservation r
                    JOIN voiture v ON r.voiture_resa = v.id_voiture
                    JOIN utilisateur u ON r.client_resa = u.id_utilisateur
                    WHERE r.id_reservation = :id";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([':id' => $id_reservation]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }


    public function getReservationsActives($id_utilisateur) {
        $sql = "SELECT r.*, v.marque, v.modele 
                FROM reservation r 
                JOIN voiture v ON r.voiture_resa = v.id_voiture 
                WHERE r.client_resa = :id_utilisateur 
                AND r.statut_reservation = 'confirmée'
                AND r.date_fin >= CURRENT_DATE()
                ORDER BY r.date_debut ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_utilisateur' => $id_utilisateur]);
        return $stmt->fetchAll();
    }

    public function getReservationsFutures($id_utilisateur) {
        $sql = "SELECT r.*, v.marque, v.modele 
                FROM reservation r 
                JOIN voiture v ON r.voiture_resa = v.id_voiture 
                WHERE r.client_resa = :id_utilisateur 
                AND r.statut_reservation = 'confirmée'
                AND r.date_debut > CURRENT_DATE()
                ORDER BY r.date_debut ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_utilisateur' => $id_utilisateur]);
        return $stmt->fetchAll();
    }

    public function getReservationsAnnulees($id_utilisateur) {
        $sql = "SELECT r.*, v.marque, v.modele 
                FROM reservation r 
                JOIN voiture v ON r.voiture_resa = v.id_voiture 
                WHERE r.client_resa = :id_utilisateur 
                AND r.statut_reservation = 'annulée'
                ORDER BY r.date_debut DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_utilisateur' => $id_utilisateur]);
        return $stmt->fetchAll();
    }
    public function getReservationsPassées($id_utilisateur) {
        $sql = "SELECT r.*, v.marque, v.modele 
                FROM reservation r 
                JOIN voiture v ON r.voiture_resa = v.id_voiture 
                WHERE r.client_resa = :id_utilisateur 
                AND r.statut_reservation = 'confirmée'
                AND r.date_fin < CURRENT_DATE()
                ORDER BY r.date_fin DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_utilisateur' => $id_utilisateur]);
        return $stmt->fetchAll();
    }
    public function getReservationsVoiture($id_voiture) {
        $sql = "SELECT r.*, u.nom_utilisateur, u.prenom_utilisateur 
                FROM reservation r 
                JOIN utilisateur u ON r.client_resa = u.id_utilisateur 
                WHERE r.voiture_resa = :id_voiture 
                ORDER BY r.date_debut DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_voiture' => $id_voiture]);
        return $stmt->fetchAll();
    }   

    public function getReservationsActivesVoiture($id_voiture) {
        $sql = "SELECT r.*, u.nom_utilisateur, u.prenom_utilisateur 
                FROM reservation r 
                JOIN utilisateur u ON r.client_resa = u.id_utilisateur 
                WHERE r.voiture_resa = :id_voiture 
                AND r.statut_reservation = 'confirmée'
                AND r.date_fin >= CURRENT_DATE()
                ORDER BY r.date_debut ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_voiture' => $id_voiture]);
        return $stmt->fetchAll();
    }

    public function getReservationsFuturesVoiture($id_voiture) {
        $sql = "SELECT r.*, u.nom_utilisateur, u.prenom_utilisateur 
                FROM reservation r 
                JOIN utilisateur u ON r.client_resa = u.id_utilisateur 
                WHERE r.voiture_resa = :id_voiture 
                AND r.statut_reservation = 'confirmée'
                AND r.date_debut > CURRENT_DATE()
                ORDER BY r.date_debut ASC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_voiture' => $id_voiture]);
        return $stmt->fetchAll();
    }

    public function getReservationsAnnuleesVoiture($id_voiture) {
        $sql = "SELECT r.*, u.nom_utilisateur, u.prenom_utilisateur 
                FROM reservation r 
                JOIN utilisateur u ON r.client_resa = u.id_utilisateur 
                WHERE r.voiture_resa = :id_voiture 
                AND r.statut_reservation = 'annulée'
                ORDER BY r.date_debut DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_voiture' => $id_voiture]);
        return $stmt->fetchAll();
    }
    public function getReservationsPasseesVoiture($id_voiture) {
        $sql = "SELECT r.*, u.nom_utilisateur, u.prenom_utilisateur 
                FROM reservation r 
                JOIN utilisateur u ON r.client_resa = u.id_utilisateur 
                WHERE r.voiture_resa = :id_voiture 
                AND r.statut_reservation = 'confirmée'
                AND r.date_fin < CURRENT_DATE()
                ORDER BY r.date_fin DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id_voiture' => $id_voiture]);
        return $stmt->fetchAll();
    }

    public function confirmerReservation($id_reservation) {
        try {
            $sql = "UPDATE reservation 
                    SET statut_reservation = 'confirmée'
                    WHERE id_reservation = :id_reservation";
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':id_reservation' => $id_reservation
            ]);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    } 
    public function annulerReservation($id_reservation) {
        try {
            $sql = "UPDATE reservation 
                    SET statut_reservation = 'annulée'
                    WHERE id_reservation = :id";
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([':id' => $id_reservation]);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return false;
        }
    }
    public function supprimer($id_reservation) {
        $sql = "DELETE FROM Reservation 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id_reservation]);
    }
    public function supprimerReservation($id_reservation) {
        $sql = "DELETE FROM Reservation 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id_reservation]);
    }
    public function supprimerReservationParVoiture($id_voiture) {
        $sql = "DELETE FROM Reservation 
                WHERE voiture_resa = :voiture";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':voiture' => $id_voiture]);
    }
    public function supprimerReservationParClient($id_client) {
        $sql = "DELETE FROM Reservation 
                WHERE client_resa = :client";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':client' => $id_client]);
    }

    // Update
    public function modifier($id_reservation, $date_debut, $date_fin) {
        $sql = "UPDATE Reservation 
                SET date_debut = :debut, date_fin = :fin 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':debut' => $date_debut,
            ':fin' => $date_fin
        ]);
    }
    public function modifierStatut($id_reservation, $statut) {
        $sql = "UPDATE Reservation 
                SET statut_reservation = :statut 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':statut' => $statut
        ]);
    }

    public function modifierVoiture($id_reservation, $id_voiture) {
        $sql = "UPDATE Reservation 
                SET voiture_resa = :voiture 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':voiture' => $id_voiture
        ]);
    }

    public function modifierClient($id_reservation, $id_client) {
        $sql = "UPDATE Reservation 
                SET client_resa = :client 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':client' => $id_client
        ]);
    }
    public function modifierDateDebut($id_reservation, $date_debut) {
        $sql = "UPDATE Reservation 
                SET date_debut = :debut 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':debut' => $date_debut
        ]);
    }
    public function modifierDateFin($id_reservation, $date_fin) {
        $sql = "UPDATE Reservation 
                SET date_fin = :fin 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':fin' => $date_fin
        ]);
    }

    // Update - Mettre à jour le statut d'une réservation

 
    public function updateStatut($id_reservation, $nouveau_statut) {
        $sql = "UPDATE Reservation 
                SET statut_reservation = :statut 
                WHERE id_reservation = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':statut' => $nouveau_statut
        ]);
    }

   
    public function annuler($id_reservation, $id_client) {
        $sql = "UPDATE Reservation 
                SET statut_reservation = 'annulée' 
                WHERE id_reservation = :id 
                AND client_resa = :client";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id_reservation,
            ':client' => $id_client
        ]);
    }

   
    public function verifierDisponibilite($id_voiture, $date_debut, $date_fin) {
        $sql = "SELECT COUNT(*) as count 
                FROM Reservation 
                WHERE voiture_resa = :voiture 
                AND statut_reservation != 'annulée'
                AND (
                    (date_debut BETWEEN :debut AND :fin)
                    OR (date_fin BETWEEN :debut AND :fin)
                    OR (:debut BETWEEN date_debut AND date_fin)
                )";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':voiture' => $id_voiture,
            ':debut' => $date_debut,
            ':fin' => $date_fin
        ]);
        
        return $stmt->fetch()['count'] == 0;
    }

    public function getDernierID() {
        return $this->db->lastInsertId();
    }
}